import React from 'react'

import { Helmet } from 'react-helmet'

import './web-page3.css'

const WebPAGE3 = (props) => {
  return (
    <div className="web-page3-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="web-page3-web-page3">
        <div className="web-page3-menu">
          <div className="web-page3-frame1">
            <div className="web-page3-frame289">
              <div className="web-page3-frame288">
                <span className="web-page3-text10">
                  <span className="web-page3-text11">HomeGym</span>
                  <span>Essentials</span>
                </span>
              </div>
            </div>
          </div>
          <div className="web-page3-searchbar">
            <div className="web-page3-frame183">
              <img
                alt="basilsearchoutline3328"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-basilsearchoutline"
              />
            </div>
          </div>
          <div className="web-page3-frame148">
            <div className="web-page3-frame147">
              <span className="web-page3-text13 TypographyH3">Home</span>
              <img
                alt="Line13328"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-line1"
              />
            </div>
            <div className="web-page3-frame291">
              <span className="web-page3-text14 TypographyH3">Shop Now</span>
              <img
                alt="oouinextltr3329"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-oouinextltr1"
              />
            </div>
            <div className="web-page3-frame295">
              <span className="web-page3-text15 TypographyH3">Categories</span>
              <img
                alt="oouinextltr3329"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-oouinextltr2"
              />
            </div>
            <div className="web-page3-frame293">
              <span className="web-page3-text16 TypographyH3">FAQ</span>
            </div>
            <div className="web-page3-frame294">
              <span className="web-page3-text17 TypographyH3">Contact Us</span>
            </div>
          </div>
          <div className="web-page3-frame290">
            <button className="web-page3-button1">
              <span className="web-page3-text18">Login</span>
            </button>
            <button className="web-page3-button2">
              <span className="web-page3-text19">Sign Up</span>
            </button>
          </div>
        </div>
        <div className="web-page3-frame-our-trainers">
          <div className="web-page3-frame361">
            <div className="web-page3-frame326">
              <span className="web-page3-text20">
                <span className="web-page3-text21">
                  Shop by
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
                <span>Category</span>
              </span>
              <div className="web-page3-frame367">
                <div className="web-page3-frame397">
                  <div className="web-page3-frame366">
                    <img
                      alt="grommeticonslinknext3355"
                      src="/grommeticonslinknext3355-47kd.svg"
                      className="web-page3-grommeticonslinknext1"
                    />
                  </div>
                  <div className="web-page3-frame365">
                    <img
                      alt="grommeticonslinknext3356"
                      src="/grommeticonslinknext3356-fv74.svg"
                      className="web-page3-grommeticonslinknext2"
                    />
                  </div>
                </div>
                <div className="web-page3-frame396">
                  <img
                    alt="Rectangle393356"
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    className="web-page3-rectangle39"
                  />
                  <img
                    alt="Rectangle403356"
                    src="/rectangle403356-cja-200h.png"
                    className="web-page3-rectangle40"
                  />
                  <img
                    alt="Rectangle413356"
                    src="/rectangle413356-cnbn-200h.png"
                    className="web-page3-rectangle41"
                  />
                  <img
                    alt="Rectangle423356"
                    src="/rectangle423356-n37-200h.png"
                    className="web-page3-rectangle42"
                  />
                  <img
                    alt="Rectangle433356"
                    src="/rectangle433356-6p8-200h.png"
                    className="web-page3-rectangle43"
                  />
                </div>
              </div>
            </div>
            <div className="web-page3-frame325">
              <span className="web-page3-text23 TypographyTextBig">
                Browse our carefully curated categories of home gym equipment.
                All products are selected for their compact design and
                effectiveness in home environments.
              </span>
            </div>
          </div>
          <div className="web-page3-frame454">
            <div className="web-page3-frame453">
              <img
                alt="Ellipse163357"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-ellipse161"
              />
              <img
                alt="Ellipse173357"
                src="https://play.teleporthq.io/static/svg/default-img.svg"
                className="web-page3-ellipse17"
              />
            </div>
            <div className="web-page3-frame395">
              <div className="web-page3-frame391">
                <img
                  alt="Frame5113357"
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  className="web-page3-frame5111"
                />
                <div className="web-page3-frame3901">
                  <div className="web-page3-frame3891">
                    <span className="web-page3-text24 TypographyH1">
                      Balance &amp; Stability
                    </span>
                    <span className="web-page3-text25 TypographyH3">
                      Balance balls, stability discs, and Medicine balls
                    </span>
                  </div>
                  <div className="web-page3-frame3171">
                    <img
                      alt="Ellipse163358"
                      src="/ellipse163358-zbts-200w.png"
                      className="web-page3-ellipse162"
                    />
                    <div className="web-page3-frame3881">
                      <span className="web-page3-text26 TypographyTextMedium">
                        Learn More
                      </span>
                      <img
                        alt="Arrow13358"
                        src="/arrow13358-hkj.svg"
                        className="web-page3-arrow11"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="web-page3-frame393">
                <img
                  alt="Frame5113358"
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  className="web-page3-frame5112"
                />
                <div className="web-page3-frame3902">
                  <div className="web-page3-frame3892">
                    <span className="web-page3-text27 TypographyH1">
                      Cardio Equipment
                    </span>
                    <span className="web-page3-text28 TypographyH3">
                      Jump ropes, stepper, and compact cardio machines
                    </span>
                  </div>
                  <div className="web-page3-frame3172">
                    <img
                      alt="Ellipse163359"
                      src="/ellipse163359-ctuq-200w.png"
                      className="web-page3-ellipse163"
                    />
                    <div className="web-page3-frame3882">
                      <span className="web-page3-text29 TypographyTextMedium">
                        Learn More
                      </span>
                      <img
                        alt="Arrow13359"
                        src="/arrow13359-47tm.svg"
                        className="web-page3-arrow12"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="web-page3-frame392">
                <img
                  alt="Frame5113359"
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  className="web-page3-frame5113"
                />
                <div className="web-page3-frame3903">
                  <div className="web-page3-frame3893">
                    <span className="web-page3-text30 TypographyH1">
                      Weights &amp; Dumbbells
                    </span>
                    <span className="web-page3-text31 TypographyH3">
                      Adjustable dumbbells, kettlebells, and weight sets
                    </span>
                  </div>
                  <div className="web-page3-frame3173">
                    <img
                      alt="Ellipse163360"
                      src="/ellipse163360-7hf-200w.png"
                      className="web-page3-ellipse164"
                    />
                    <div className="web-page3-frame3883">
                      <span className="web-page3-text32 TypographyTextMedium">
                        Learn More
                      </span>
                      <img
                        alt="Arrow13360"
                        src="/arrow13360-47er.svg"
                        className="web-page3-arrow13"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="web-page3-frame394">
                <img
                  alt="Frame5113360"
                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                  className="web-page3-frame5114"
                />
                <div className="web-page3-frame3904">
                  <div className="web-page3-frame3894">
                    <span className="web-page3-text33 TypographyH1">
                      Yoga &amp; Flexibility
                    </span>
                    <span className="web-page3-text34 TypographyH3">
                      Yoga mats, blocks, straps, and flexibility tools
                    </span>
                  </div>
                  <div className="web-page3-frame3174">
                    <img
                      alt="Ellipse163361"
                      src="/ellipse163361-xfpx-200w.png"
                      className="web-page3-ellipse165"
                    />
                    <div className="web-page3-frame3884">
                      <span className="web-page3-text35 TypographyTextMedium">
                        Learn More
                      </span>
                      <img
                        alt="Arrow13361"
                        src="/arrow13361-6a7e.svg"
                        className="web-page3-arrow14"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button className="web-page3-button3">
            <span className="web-page3-text36">View All</span>
            <img
              alt="oouinextltrI336"
              src="https://play.teleporthq.io/static/svg/default-img.svg"
              className="web-page3-oouinextltr3"
            />
          </button>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="web-page3-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="web-page3-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="web-page3-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="web-page3-text37">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default WebPAGE3
