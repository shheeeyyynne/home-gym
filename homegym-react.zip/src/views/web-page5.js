import React from 'react'

import { Helmet } from 'react-helmet'

import './web-page5.css'

const WebPAGE5 = (props) => {
  return (
    <div className="web-page5-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="web-page5-web-page5">
        <div className="web-page5-menu">
          <div className="web-page5-frame1">
            <div className="web-page5-frame289">
              <div className="web-page5-frame288">
                <span className="web-page5-text10">
                  <span className="web-page5-text11">HomeGym</span>
                  <span>Essentials</span>
                </span>
              </div>
            </div>
          </div>
          <div className="web-page5-searchbar">
            <div className="web-page5-frame183">
              <img
                alt="basilsearchoutline3348"
                src="/basilsearchoutline3348-fg9.svg"
                className="web-page5-basilsearchoutline"
              />
            </div>
          </div>
          <div className="web-page5-frame148">
            <div className="web-page5-frame147">
              <span className="web-page5-text13 TypographyH3">Home</span>
              <img
                alt="Line13349"
                src="/line13349-utrg.svg"
                className="web-page5-line1"
              />
            </div>
            <div className="web-page5-frame291">
              <span className="web-page5-text14 TypographyH3">Shop Now</span>
              <img
                alt="oouinextltr3349"
                src="/oouinextltr3349-nqx9.svg"
                className="web-page5-oouinextltr1"
              />
            </div>
            <div className="web-page5-frame295">
              <span className="web-page5-text15 TypographyH3">Categories</span>
              <img
                alt="oouinextltr3350"
                src="/oouinextltr3350-4qjn.svg"
                className="web-page5-oouinextltr2"
              />
            </div>
            <div className="web-page5-frame293">
              <span className="web-page5-text16 TypographyH3">FAQ</span>
            </div>
            <div className="web-page5-frame294">
              <span className="web-page5-text17 TypographyH3">Contact Us</span>
            </div>
          </div>
          <div className="web-page5-frame290">
            <button className="web-page5-button1">
              <span className="web-page5-text18">Login</span>
            </button>
            <button className="web-page5-button2">
              <span className="web-page5-text19">Sign Up</span>
            </button>
          </div>
        </div>
        <div className="web-page5-sign-in-login">
          <div className="web-page5-frame449">
            <img
              alt="Ellipse203377"
              src="/ellipse203377-n2mo-700w.png"
              className="web-page5-ellipse20"
            />
            <img
              alt="Ellipse213377"
              src="/ellipse213377-tox-400w.png"
              className="web-page5-ellipse21"
            />
          </div>
          <div className="web-page5-frame450">
            <div className="web-page5-frame401">
              <div className="web-page5-frame110">
                <div className="web-page5-frame108">
                  <div className="web-page5-frame96">
                    <div className="web-page5-frame31">
                      <span className="web-page5-text20 Heading1">Sign Up</span>
                      <img
                        alt="Line303381"
                        src="/line303381-bra.svg"
                        className="web-page5-line30"
                      />
                    </div>
                    <span className="web-page5-text21 Heading2">Login</span>
                  </div>
                  <div className="web-page5-frame104">
                    <span className="web-page5-text22 Heading3">Name</span>
                    <div className="web-page5-frame98">
                      <div className="web-page5-frame24">
                        <img
                          alt="miuser3381"
                          src="/miuser3381-k58u.svg"
                          className="web-page5-miuser"
                        />
                        <span className="web-page5-text23">
                          Enter Your Name
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="web-page5-frame105">
                    <span className="web-page5-text24 Heading3">E-Mail</span>
                    <div className="web-page5-frame99">
                      <div className="web-page5-frame23">
                        <img
                          alt="octiconmail243382"
                          src="/octiconmail243382-jmf.svg"
                          className="web-page5-octiconmail24"
                        />
                        <span className="web-page5-text25">
                          Enter Your E-Mail
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="web-page5-frame107">
                  <button className="web-page5-button3">
                    <span className="web-page5-text26">Sign Up</span>
                  </button>
                  <div className="web-page5-frame101">
                    <span className="web-page5-text27 Heading3">Or</span>
                    <img
                      alt="Line313383"
                      src="/line313383-j4jl.svg"
                      className="web-page5-line31"
                    />
                    <img
                      alt="Line323383"
                      src="/line323383-lzlp.svg"
                      className="web-page5-line32"
                    />
                  </div>
                  <div className="web-page5-frame102">
                    <div className="web-page5-frame32">
                      <img
                        alt="devicongoogle3383"
                        src="/devicongoogle3383-xcf.svg"
                        className="web-page5-devicongoogle"
                      />
                      <span className="web-page5-text28 Heading3">
                        Sign Up With Google
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="web-page5-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="web-page5-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="web-page5-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="web-page5-text29">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default WebPAGE5
