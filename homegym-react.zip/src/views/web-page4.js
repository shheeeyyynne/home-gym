import React from 'react'

import { Helmet } from 'react-helmet'

import './web-page4.css'

const WebPAGE4 = (props) => {
  return (
    <div className="web-page4-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="web-page4-web-page4">
        <div className="web-page4-menu">
          <div className="web-page4-frame1">
            <div className="web-page4-frame289">
              <div className="web-page4-frame288">
                <span className="web-page4-text10">
                  <span className="web-page4-text11">HomeGym</span>
                  <span>Essentials</span>
                </span>
              </div>
            </div>
          </div>
          <div className="web-page4-searchbar">
            <div className="web-page4-frame183">
              <img
                alt="basilsearchoutline3339"
                src="/basilsearchoutline3339-fsu8.svg"
                className="web-page4-basilsearchoutline"
              />
            </div>
          </div>
          <div className="web-page4-frame148">
            <div className="web-page4-frame147">
              <span className="web-page4-text13 TypographyH3">Home</span>
              <img
                alt="Line13339"
                src="/line13339-sm1b.svg"
                className="web-page4-line1"
              />
            </div>
            <div className="web-page4-frame291">
              <span className="web-page4-text14 TypographyH3">Shop Now</span>
              <img
                alt="oouinextltr3340"
                src="/oouinextltr3340-32i.svg"
                className="web-page4-oouinextltr1"
              />
            </div>
            <div className="web-page4-frame295">
              <span className="web-page4-text15 TypographyH3">Categories</span>
              <img
                alt="oouinextltr3340"
                src="/oouinextltr3340-87sm.svg"
                className="web-page4-oouinextltr2"
              />
            </div>
            <div className="web-page4-frame293">
              <span className="web-page4-text16 TypographyH3">FAQ</span>
            </div>
            <div className="web-page4-frame294">
              <span className="web-page4-text17 TypographyH3">Contact Us</span>
            </div>
          </div>
          <div className="web-page4-frame290">
            <button className="web-page4-button1">
              <span className="web-page4-text18">Login</span>
            </button>
            <button className="web-page4-button2">
              <span className="web-page4-text19">Sign Up</span>
            </button>
          </div>
        </div>
        <div className="web-page4faq">
          <div className="web-page4-frame383">
            <div className="web-page4-frame33">
              <span className="web-page4-text20">FAQ</span>
            </div>
          </div>
          <div className="web-page4-frame3821">
            <div className="web-page4-frame449">
              <img
                alt="Ellipse203344"
                src="/ellipse203344-lx6j-600w.png"
                className="web-page4-ellipse20"
              />
              <img
                alt="Ellipse213345"
                src="/ellipse213345-oene-500h.png"
                className="web-page4-ellipse21"
              />
            </div>
            <div className="web-page4-frame385">
              <div className="web-page4-frame381">
                <div className="web-page4-frame380">
                  <div className="web-page4-frame379">
                    <span className="web-page4-text21 TypographyH2">
                      What makes home gym equipment different from commercial
                      gym equipment?
                    </span>
                    <img
                      alt="grommeticonsnext3345"
                      src="/grommeticonsnext3345-9z37.svg"
                      className="web-page4-grommeticonsnext1"
                    />
                  </div>
                </div>
                <div className="web-page4-frame386">
                  <span className="web-page4-text22 TypographyTextBig">
                    Home gym equipment is specifically designed to be compact,
                    space-efficient, and suitable for residential use. It
                    focuses on versatility and storage while maintaining
                    effectiveness. Our products are selected to fit in smaller
                    spaces without compromising on workout quality.
                  </span>
                </div>
              </div>
              <div className="web-page4-frame376">
                <div className="web-page4-frame375">
                  <span className="web-page4-text23 TypographyH2">
                    How do I know which equipment is right for my fitness level?
                  </span>
                  <img
                    alt="grommeticonsnext3346"
                    src="/grommeticonsnext3346-43l.svg"
                    className="web-page4-grommeticonsnext2"
                  />
                </div>
              </div>
              <div className="web-page4-frame365">
                <div className="web-page4-frame372">
                  <span className="web-page4-text24 TypographyH2">
                    Do you offer assembly and setup services?
                  </span>
                  <img
                    alt="grommeticonsnext3346"
                    src="/grommeticonsnext3346-ofww.svg"
                    className="web-page4-grommeticonsnext3"
                  />
                </div>
              </div>
              <div className="web-page4-frame366">
                <div className="web-page4-frame3731">
                  <span className="web-page4-text25 TypographyH2">
                    Do you offer workout guides or training programs?
                  </span>
                  <img
                    alt="grommeticonsnext3347"
                    src="/grommeticonsnext3347-r6x.svg"
                    className="web-page4-grommeticonsnext4"
                  />
                </div>
              </div>
              <div className="web-page4-frame3822">
                <div className="web-page4-frame3732">
                  <span className="web-page4-text26 TypographyH2">
                    Can I combine different equipment for a complete workout?
                  </span>
                  <img
                    alt="grommeticonsnext3347"
                    src="/grommeticonsnext3347-4srd.svg"
                    className="web-page4-grommeticonsnext5"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="web-page4-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="web-page4-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="web-page4-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="web-page4-text27">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default WebPAGE4
