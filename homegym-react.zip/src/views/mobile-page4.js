import React from 'react'

import { Helmet } from 'react-helmet'

import './mobile-page4.css'

const MobilePAGE4 = (props) => {
  return (
    <div className="mobile-page4-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="mobile-page4-mobile-page4">
        <div className="mobile-page4-menu">
          <div className="mobile-page4-frame470">
            <div className="mobile-page4-frame1">
              <span className="mobile-page4-text10">
                <span className="mobile-page4-text11">HomeGym</span>
                <span>Essentials</span>
              </span>
            </div>
            <div className="mobile-page4-searchbar">
              <div className="mobile-page4-frame183">
                <img
                  alt="basilsearchoutline3459"
                  src="/basilsearchoutline3459-5y0b.svg"
                  className="mobile-page4-basilsearchoutline"
                />
              </div>
              <div className="mobile-page4-frame475">
                <span className="mobile-page4-text13 TypographyTextSmall">
                  Search
                </span>
              </div>
            </div>
          </div>
          <img
            alt="icroundmenu3463"
            src="/icroundmenu3463-7p4u.svg"
            className="mobile-page4-icroundmenu"
          />
        </div>
        <div className="mobile-page4faq">
          <div className="mobile-page4-frame383">
            <div className="mobile-page4-frame33">
              <span className="mobile-page4-text14 TypographyH1">FAQ</span>
            </div>
          </div>
          <div className="mobile-page4-frame3821">
            <div className="mobile-page4-frame449">
              <img
                alt="Ellipse203491"
                src="/ellipse203491-9qyw-400w.png"
                className="mobile-page4-ellipse20"
              />
            </div>
            <div className="mobile-page4-frame385">
              <div className="mobile-page4-frame381">
                <div className="mobile-page4-frame380">
                  <div className="mobile-page4-frame379">
                    <span className="mobile-page4-text15">
                      What makes home gym equipment different from commercial
                      gym equipment?
                    </span>
                    <img
                      alt="grommeticonsnext3497"
                      src="/grommeticonsnext3497-0a6p.svg"
                      className="mobile-page4-grommeticonsnext1"
                    />
                  </div>
                </div>
                <div className="mobile-page4-frame386">
                  <span className="mobile-page4-text16 TypographyTextBig">
                    Home gym equipment is specifically designed to be compact,
                    space-efficient, and suitable for residential use. It
                    focuses on versatility and storage while maintaining
                    effectiveness. Our products are selected to fit in smaller
                    spaces without compromising on workout quality.
                  </span>
                </div>
              </div>
              <div className="mobile-page4-frame376">
                <div className="mobile-page4-frame375">
                  <span className="mobile-page4-text17">
                    How do I know which equipment is right for my fitness level?
                  </span>
                  <img
                    alt="grommeticonsnext3410"
                    src="/grommeticonsnext3410-ek6rp.svg"
                    className="mobile-page4-grommeticonsnext2"
                  />
                </div>
              </div>
              <div className="mobile-page4-frame365">
                <div className="mobile-page4-frame372">
                  <span className="mobile-page4-text18">
                    Do you offer assembly and setup services?
                  </span>
                  <img
                    alt="grommeticonsnext3410"
                    src="/grommeticonsnext3410-h2i2.svg"
                    className="mobile-page4-grommeticonsnext3"
                  />
                </div>
              </div>
              <div className="mobile-page4-frame366">
                <div className="mobile-page4-frame3731">
                  <span className="mobile-page4-text19">
                    Do you offer workout guides or training programs?
                  </span>
                  <img
                    alt="grommeticonsnext3411"
                    src="/grommeticonsnext3411-szzn.svg"
                    className="mobile-page4-grommeticonsnext4"
                  />
                </div>
              </div>
              <div className="mobile-page4-frame3822">
                <div className="mobile-page4-frame3732">
                  <span className="mobile-page4-text20">
                    Can I combine different equipment for a complete workout?
                  </span>
                  <img
                    alt="grommeticonsnext3411"
                    src="/grommeticonsnext3411-cewp.svg"
                    className="mobile-page4-grommeticonsnext5"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="mobile-page4-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="mobile-page4-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mobile-page4-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="mobile-page4-text21">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default MobilePAGE4
