import React from 'react'

import { Helmet } from 'react-helmet'

import './web-page1.css'

const WebPAGE1 = (props) => {
  return (
    <div className="web-page1-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="web-page1-web-page1">
        <div className="web-page1-menu">
          <div className="web-page1-frame1">
            <div className="web-page1-frame289">
              <div className="web-page1-frame288">
                <span className="web-page1-text10">
                  <span className="web-page1-text11">HomeGym</span>
                  <span>Essentials</span>
                </span>
              </div>
            </div>
          </div>
          <div className="web-page1-searchbar">
            <div className="web-page1-frame183">
              <img
                alt="basilsearchoutline2520"
                src="/basilsearchoutline2520-ay69.svg"
                className="web-page1-basilsearchoutline"
              />
            </div>
          </div>
          <div className="web-page1-frame148">
            <div className="web-page1-frame147">
              <span className="web-page1-text13 TypographyH3">Home</span>
              <img
                alt="Line12520"
                src="/line12520-gqi6.svg"
                className="web-page1-line1"
              />
            </div>
            <div className="web-page1-frame291">
              <span className="web-page1-text14 TypographyH3">Shop Now</span>
              <img
                alt="oouinextltr2520"
                src="/oouinextltr2520-h2e.svg"
                className="web-page1-oouinextltr1"
              />
            </div>
            <div className="web-page1-frame295">
              <span className="web-page1-text15 TypographyH3">Categories</span>
              <img
                alt="oouinextltr2520"
                src="/oouinextltr2520-4fa.svg"
                className="web-page1-oouinextltr2"
              />
            </div>
            <div className="web-page1-frame293">
              <span className="web-page1-text16 TypographyH3">FAQ</span>
            </div>
            <div className="web-page1-frame294">
              <span className="web-page1-text17 TypographyH3">Contact Us</span>
            </div>
          </div>
          <div className="web-page1-frame290">
            <button className="web-page1-button1">
              <span className="web-page1-text18">Login</span>
            </button>
            <button className="web-page1-button2">
              <span className="web-page1-text19">Sign Up</span>
            </button>
          </div>
        </div>
        <div className="web-page1-color">
          <img
            alt="Ellipse122520"
            src="/ellipse122520-ejxu-700h.png"
            className="web-page1-ellipse12"
          />
          <img
            alt="Ellipse112520"
            src="/ellipse112520-snh9-400w.png"
            className="web-page1-ellipse111"
          />
        </div>
        <div className="web-page1-hero-section">
          <div className="web-page1-frame303">
            <div className="web-page1-frame300"></div>
            <div className="web-page1-frame301">
              <span className="web-page1-text20 TypographyTextMedium">
                Discover compact, high-quality fitness equipment designed
                specifically for home use. Build your perfect workout space
                without the bulk of commercial gym equipment.
              </span>
            </div>
          </div>
          <div className="web-page1-group4">
            <div className="web-page1-group2">
              <img
                alt="Ellipse72520"
                src="/ellipse72520-2cta-600h.png"
                className="web-page1-ellipse7"
              />
              <div className="web-page1-frame463">
                <img
                  alt="handsomemuscularblondmalewhitetshirtholdsdumbbellg2520"
                  src="/handsomemuscularblondmalewhitetshirtholdsdumbbellg2520-ah9c-700h.png"
                  className="web-page1-handsomemuscularblondmalewhitetshirtholdsdumbbellg"
                />
              </div>
            </div>
            <div className="web-page1-group3">
              <img
                alt="Ellipse102520"
                src="/ellipse102520-2mhe-200h.png"
                className="web-page1-ellipse10"
              />
              <img
                alt="Ellipse112520"
                src="/ellipse112520-vr0l-200h.png"
                className="web-page1-ellipse112"
              />
              <div className="web-page1-frame296">
                <span className="web-page1-text21 TypographyH2">+ 10</span>
                <span className="web-page1-text22 TypographyTextSmall">
                  Categories
                </span>
              </div>
              <div className="web-page1-frame297">
                <span className="web-page1-text23 TypographyH2">+ 100</span>
                <span className="web-page1-text24 TypographyTextSmall">
                  Positive Reviews
                </span>
              </div>
              <div className="web-page1-frame299">
                <span className="web-page1-text25 TypographyH2">+ 100</span>
                <span className="web-page1-text26 TypographyTextSmall">
                  Products
                </span>
              </div>
              <div className="web-page1-frame298">
                <span className="web-page1-text27 TypographyH2">PREMIUM</span>
                <span className="web-page1-text28 TypographyTextSmall">
                  Equipments
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="web-page1-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="web-page1-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="web-page1-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="web-page1-text29">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default WebPAGE1
