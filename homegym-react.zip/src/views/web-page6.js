import React from 'react'

import { Helmet } from 'react-helmet'

import './web-page6.css'

const WebPAGE6 = (props) => {
  return (
    <div className="web-page6-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="web-page6-web-page6">
        <div className="web-page6-menu">
          <div className="web-page6-frame11">
            <div className="web-page6-frame2891">
              <div className="web-page6-frame2881">
                <span className="web-page6-text10">
                  <span className="web-page6-text11">HomeGym</span>
                  <span>Essentials</span>
                </span>
              </div>
            </div>
          </div>
          <div className="web-page6-searchbar">
            <div className="web-page6-frame183">
              <img
                alt="basilsearchoutline3385"
                src="/basilsearchoutline3385-7vb.svg"
                className="web-page6-basilsearchoutline"
              />
            </div>
          </div>
          <div className="web-page6-frame148">
            <div className="web-page6-frame147">
              <span className="web-page6-text13 TypographyH3">Home</span>
              <img
                alt="Line13385"
                src="/line13385-epq.svg"
                className="web-page6-line1"
              />
            </div>
            <div className="web-page6-frame291">
              <span className="web-page6-text14 TypographyH3">Shop Now</span>
              <img
                alt="oouinextltr3385"
                src="/oouinextltr3385-tpps.svg"
                className="web-page6-oouinextltr1"
              />
            </div>
            <div className="web-page6-frame295">
              <span className="web-page6-text15 TypographyH3">Categories</span>
              <img
                alt="oouinextltr3386"
                src="/oouinextltr3386-mrq.svg"
                className="web-page6-oouinextltr2"
              />
            </div>
            <div className="web-page6-frame293">
              <span className="web-page6-text16 TypographyH3">FAQ</span>
            </div>
            <div className="web-page6-frame294">
              <span className="web-page6-text17 TypographyH3">Contact Us</span>
            </div>
          </div>
          <div className="web-page6-frame290">
            <button className="web-page6-button1">
              <span className="web-page6-text18">Login</span>
            </button>
            <button className="web-page6-button2">
              <span className="web-page6-text19">Sign Up</span>
            </button>
          </div>
        </div>
        <div className="web-page6-frame462">
          <div className="web-page6-frame158">
            <div className="web-page6-frame12">
              <div className="web-page6-frame2892">
                <div className="web-page6-frame2882">
                  <img
                    alt="Rectangle23440"
                    src="/rectangle23440-icy8-200h.png"
                    className="web-page6-rectangle2"
                  />
                  <span className="web-page6-text20 TypographyH1">
                    <span className="web-page6-text21">HomeGym</span>
                    <span>Essentials</span>
                  </span>
                </div>
                <span className="web-page6-text23 TypographyTextBig">
                  Transform Your Body
                </span>
              </div>
            </div>
            <div className="web-page6-frame233">
              <span className="web-page6-text24 Textmedium">
                <span>
                  Your trusted source for compact, high-quality home gym
                  equipment. Transform any space into your personal fitness
                  sanctuary.
                </span>
                <br></br>
              </span>
            </div>
            <div className="web-page6-frame236">
              <div className="web-page6-frame30">
                <img
                  alt="streamlinecomputerlogofacebook1mediafacebooksocial3440"
                  src="/streamlinecomputerlogofacebook1mediafacebooksocial3440-5rk4.svg"
                  className="web-page6-streamlinecomputerlogofacebook1mediafacebooksocial"
                />
                <div className="web-page6-lucideinstagram">
                  <div className="web-page6-group1">
                    <img
                      alt="Vector3441"
                      src="/vector3441-4mvl.svg"
                      className="web-page6-vector1"
                    />
                    <img
                      alt="Vector3441"
                      src="/vector3441-xtm.svg"
                      className="web-page6-vector2"
                    />
                  </div>
                </div>
                <div className="web-page6-primetwitter">
                  <div className="web-page6-group2">
                    <div className="web-page6-clippathgroup">
                      <div className="web-page6-prime-twitter0">
                        <img
                          alt="Vector3441"
                          src="/vector3441-swwp.svg"
                          className="web-page6-vector3"
                        />
                      </div>
                      <div className="web-page6-group3">
                        <img
                          alt="Vector3442"
                          src="/vector3442-1n3.svg"
                          className="web-page6-vector4"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="web-page6-basilyoutubeoutline">
                  <div className="web-page6-group4">
                    <img
                      alt="Vector3442"
                      src="/vector3442-ibm7.svg"
                      className="web-page6-vector5"
                    />
                    <img
                      alt="Vector3442"
                      src="/vector3442-eb2m.svg"
                      className="web-page6-vector6"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="web-page6-support">
            <div className="web-page6-frame">
              <div className="web-page6-frame26">
                <div className="web-page6-frame231">
                  <span className="web-page6-text27 TypographyH2">
                    Contact Us
                  </span>
                </div>
              </div>
              <div className="web-page6-frame29">
                <div className="web-page6-frame459">
                  <img
                    alt="carbonlocation3448"
                    src="/carbonlocation3448-yx7.svg"
                    className="web-page6-carbonlocation"
                  />
                  <span className="web-page6-text28 TypographyTextSmall">
                    Manila - Philippines
                  </span>
                </div>
                <div className="web-page6-frame460">
                  <img
                    alt="fluentcall16regular3449"
                    src="/fluentcall16regular3449-hbf.svg"
                    className="web-page6-fluentcall16regular"
                  />
                  <span className="web-page6-text29 TypographyTextSmall">
                    1234-56789
                  </span>
                </div>
                <div className="web-page6-frame461">
                  <img
                    alt="materialsymbolsmailoutline3449"
                    src="/materialsymbolsmailoutline3449-npx.svg"
                    className="web-page6-materialsymbolsmailoutline"
                  />
                  <span className="web-page6-text30 TypographyTextSmall">
                    homegymessentials@Gmail.com
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="web-page6-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="web-page6-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="web-page6-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="web-page6-text31">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default WebPAGE6
