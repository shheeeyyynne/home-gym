import React from 'react'

import { Helmet } from 'react-helmet'

import './mobile-page2.css'

const MobilePAGE2 = (props) => {
  return (
    <div className="mobile-page2-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="mobile-page2-mobile-page2">
        <div className="mobile-page2-menu">
          <div className="mobile-page2-frame470">
            <div className="mobile-page2-frame1">
              <span className="mobile-page2-text10">
                <span className="mobile-page2-text11">HomeGym</span>
                <span>Essentials</span>
              </span>
            </div>
            <div className="mobile-page2-searchbar">
              <div className="mobile-page2-frame183">
                <img
                  alt="basilsearchoutline3316"
                  src="/basilsearchoutline3316-huns.svg"
                  className="mobile-page2-basilsearchoutline"
                />
              </div>
              <div className="mobile-page2-frame475">
                <span className="mobile-page2-text13 TypographyTextSmall">
                  Search
                </span>
              </div>
            </div>
          </div>
          <img
            alt="icroundmenu3316"
            src="/icroundmenu3316-q2fu.svg"
            className="mobile-page2-icroundmenu"
          />
        </div>
        <div className="mobile-page2-our-plans">
          <div className="mobile-page2-frame361">
            <div className="mobile-page2-frame326">
              <span className="mobile-page2-text14 TypographyH2">
                <span className="mobile-page2-text15">
                  See our
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
                <span>Products</span>
              </span>
            </div>
            <div className="mobile-page2-frame325">
              <span className="mobile-page2-text17 TypographyTextBig">
                Discover our most popular compact fitness equipment designed
                specifically for home use. Each product includes detailed
                definitions to help you understand its benefits.
              </span>
            </div>
          </div>
        </div>
        <div className="mobile-page2-frame391">
          <img
            alt="Frame5113317"
            src="/frame5113317-84g-300h.png"
            className="mobile-page2-frame5111"
          />
          <div className="mobile-page2-frame3901">
            <div className="mobile-page2-frame3891">
              <span className="mobile-page2-text18 TypographyH1">
                Medicine Ball
              </span>
              <span className="mobile-page2-text19 TypographyH3">
                Balance balls, stability discs, and Medicine balls
              </span>
            </div>
          </div>
          <div className="mobile-page2-frame3491">
            <span className="mobile-page2-text20">
              <span className="mobile-page2-text21">149$</span>
              <span>/USDT</span>
            </span>
          </div>
          <button className="mobile-page2-button1">
            <span className="mobile-page2-text23">Add to Cart</span>
          </button>
        </div>
        <div className="mobile-page2-frame393">
          <img
            alt="Frame5113318"
            src="/frame5113318-8w2h-200w.png"
            className="mobile-page2-frame5112"
          />
          <div className="mobile-page2-frame3902">
            <div className="mobile-page2-frame3892">
              <span className="mobile-page2-text24 TypographyH1">
                Jump Rope
              </span>
              <span className="mobile-page2-text25 TypographyH3">
                Jump ropes, stepper, and compact cardio machines
              </span>
            </div>
          </div>
          <div className="mobile-page2-frame3492">
            <span className="mobile-page2-text26">
              <span className="mobile-page2-text27">149$</span>
              <span>/USDT</span>
            </span>
          </div>
          <button className="mobile-page2-button2">
            <span className="mobile-page2-text29">Add to Cart</span>
          </button>
        </div>
        <button className="mobile-page2-button3">
          <span className="mobile-page2-text30">View All</span>
          <img
            alt="oouinextltrI331"
            src="/oouinextltri331-ng4q.svg"
            className="mobile-page2-oouinextltr"
          />
        </button>
      </div>
      <a href="https://play.teleporthq.io/signup" className="mobile-page2-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="mobile-page2-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mobile-page2-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="mobile-page2-text31">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default MobilePAGE2
