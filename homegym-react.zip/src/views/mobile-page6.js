import React from 'react'

import { Helmet } from 'react-helmet'

import './mobile-page6.css'

const MobilePAGE6 = (props) => {
  return (
    <div className="mobile-page6-container1">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="mobile-page6-mobile-page6">
        <div className="mobile-page6-menu">
          <div className="mobile-page6-frame470">
            <div className="mobile-page6-frame11">
              <span className="mobile-page6-text10">
                <span className="mobile-page6-text11">HomeGym</span>
                <span>Essentials</span>
              </span>
            </div>
            <div className="mobile-page6-searchbar">
              <div className="mobile-page6-frame183">
                <img
                  alt="basilsearchoutline3424"
                  src="/basilsearchoutline3424-o6tl.svg"
                  className="mobile-page6-basilsearchoutline"
                />
              </div>
              <div className="mobile-page6-frame475">
                <span className="mobile-page6-text13 TypographyTextSmall">
                  Search
                </span>
              </div>
            </div>
          </div>
          <img
            alt="icroundmenu3425"
            src="/icroundmenu3425-0pys.svg"
            className="mobile-page6-icroundmenu"
          />
        </div>
        <div className="mobile-page6-frame462">
          <div className="mobile-page6-frame158">
            <div className="mobile-page6-frame12">
              <div className="mobile-page6-frame289">
                <div className="mobile-page6-frame288">
                  <span className="mobile-page6-text14 TypographyH2">
                    <span className="mobile-page6-text15">HomeGym</span>
                    <span>Essentials</span>
                  </span>
                </div>
              </div>
            </div>
            <div className="mobile-page6-frame233">
              <span className="mobile-page6-text17 TypographyTextSmall">
                Your trusted source for compact, high-quality home gym
                equipment. Transform any space into your personal fitness
                sanctuary.
              </span>
            </div>
            <div className="mobile-page6-frame236">
              <div className="mobile-page6-frame30">
                <img
                  alt="streamlinecomputerlogofacebook1mediafacebooksocial3430"
                  src="/streamlinecomputerlogofacebook1mediafacebooksocial3430-a6ar.svg"
                  className="mobile-page6-streamlinecomputerlogofacebook1mediafacebooksocial"
                />
                <div className="mobile-page6-lucideinstagram">
                  <div className="mobile-page6-group1">
                    <img
                      alt="Vector3431"
                      src="/vector3431-hpr.svg"
                      className="mobile-page6-vector1"
                    />
                    <img
                      alt="Vector3431"
                      src="/vector3431-fus.svg"
                      className="mobile-page6-vector2"
                    />
                  </div>
                </div>
                <div className="mobile-page6-primetwitter">
                  <div className="mobile-page6-group2">
                    <div className="mobile-page6-clippathgroup">
                      <div className="mobile-page6-prime-twitter0">
                        <img
                          alt="Vector3431"
                          src="/vector3431-u3y7.svg"
                          className="mobile-page6-vector3"
                        />
                      </div>
                      <div className="mobile-page6-group3">
                        <img
                          alt="Vector3432"
                          src="/vector3432-x6p.svg"
                          className="mobile-page6-vector4"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mobile-page6-basilyoutubeoutline">
                  <div className="mobile-page6-group4">
                    <img
                      alt="Vector3432"
                      src="/vector3432-3rbtm.svg"
                      className="mobile-page6-vector5"
                    />
                    <img
                      alt="Vector3432"
                      src="/vector3432-or3j.svg"
                      className="mobile-page6-vector6"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mobile-page6-support">
            <div className="mobile-page6-frame">
              <div className="mobile-page6-frame26">
                <div className="mobile-page6-frame231">
                  <span className="mobile-page6-text18">Contact Us</span>
                </div>
              </div>
              <div className="mobile-page6-frame29">
                <div className="mobile-page6-frame459">
                  <img
                    alt="carbonlocation3438"
                    src="/carbonlocation3438-awq.svg"
                    className="mobile-page6-carbonlocation"
                  />
                  <span className="mobile-page6-text19 TypographyTextSmall">
                    Manila - Philippines
                  </span>
                </div>
                <div className="mobile-page6-frame460">
                  <img
                    alt="fluentcall16regular3438"
                    src="/fluentcall16regular3438-yf4h.svg"
                    className="mobile-page6-fluentcall16regular"
                  />
                  <span className="mobile-page6-text20 TypographyTextSmall">
                    1234-56789
                  </span>
                </div>
                <div className="mobile-page6-frame461">
                  <img
                    alt="materialsymbolsmailoutline3439"
                    src="/materialsymbolsmailoutline3439-z239.svg"
                    className="mobile-page6-materialsymbolsmailoutline"
                  />
                  <span className="mobile-page6-text21 TypographyTextSmall">
                    homegymessentials@Gmail.com
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="mobile-page6-link">
        <div
          aria-label="Sign up to TeleportHQ"
          className="mobile-page6-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mobile-page6-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="mobile-page6-text22">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default MobilePAGE6
