import React from 'react'
import ReactDOM from 'react-dom'
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from 'react-router-dom'

import './style.css'
import WebPAGE4 from './views/web-page4'
import WebPAGE2 from './views/web-page2'
import MobilePAGE5 from './views/mobile-page5'
import MobilePAGE6 from './views/mobile-page6'
import MobilePAGE2 from './views/mobile-page2'
import MobilePAGE3 from './views/mobile-page3'
import MobilePAGE4 from './views/mobile-page4'
import WebPAGE6 from './views/web-page6'
import WebPAGE1 from './views/web-page1'
import WebPAGE5 from './views/web-page5'
import MobilePAGE1 from './views/mobile-page1'
import WebPAGE3 from './views/web-page3'
import NotFound from './views/not-found'

const App = () => {
  return (
    <Router>
      <Switch>
        <Route component={WebPAGE4} exact path="/web-page4" />
        <Route component={WebPAGE2} exact path="/web-page2" />
        <Route component={MobilePAGE5} exact path="/mobile-page5" />
        <Route component={MobilePAGE6} exact path="/mobile-page6" />
        <Route component={MobilePAGE2} exact path="/mobile-page2" />
        <Route component={MobilePAGE3} exact path="/mobile-page3" />
        <Route component={MobilePAGE4} exact path="/mobile-page4" />
        <Route component={WebPAGE6} exact path="/web-page6" />
        <Route component={WebPAGE1} exact path="/" />
        <Route component={WebPAGE5} exact path="/web-page5" />
        <Route component={MobilePAGE1} exact path="/mobile-page1" />
        <Route component={WebPAGE3} exact path="/web-page3" />
        <Route component={NotFound} path="**" />
        <Redirect to="**" />
      </Switch>
    </Router>
  )
}

ReactDOM.render(<App />, document.getElementById('app'))
